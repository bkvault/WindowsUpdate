
Install-WindowsUpdate -ForceDownload  -ForceInstall –AcceptAll 